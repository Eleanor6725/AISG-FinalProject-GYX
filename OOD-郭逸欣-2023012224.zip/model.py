from collections import OrderedDict
import numpy as np
import torch
import torch.nn as nn
from register import Register

class Output(nn.Module):
    def __init__(self, input_dim, output_dim, init=1, bias=False):
        super(Output, self).__init__()
        assert (input_dim >= output_dim)
        data = torch.zeros(output_dim, input_dim)
        for i in range(output_dim):
            data[i, i] = init
        self.weight = nn.Parameter(data)
        self.is_bias = bias
        if self.is_bias:
            data = torch.zeros(output_dim)
            self.bias = nn.Parameter(data)
        
    def forward(self, x):
        if self.is_bias:
            out = torch.mm(x, self.weight.t()) + self.bias
        else:
            out = torch.mm(x, self.weight.t())
        return out

class MLP(nn.Module):
    def __init__(self, input_dim, hidden_size, drop_rate=0, batchnorm=False, output_features=1, bias=True):
        '''
        Args:
            hidden_size: list of hidden unit dimensions, the number of elements equal the humber of hidden layers.
        '''
        super(MLP, self).__init__()
        self.hidden_size = [input_dim] + hidden_size # self.hidden_size: [input dim, hidden dims, ...]
        self.hidden_layers = []
        # input layer and hidden layers
        for i in range(len(self.hidden_size) - 1):
            input_dim = self.hidden_size[i]
            output_dim = self.hidden_size[i + 1]
            self.hidden_layers.append((f'linear{i+1}', nn.Linear(
                            in_features = input_dim,
                            out_features = output_dim,
                            bias=bias
                        )))
            if batchnorm:
                self.hidden_layers.append((f'batchnorm{i+1}', nn.BatchNorm1d(num_features=output_dim)))
            self.hidden_layers.append((f'relu{i+1}', nn.ReLU()))
            self.hidden_layers.append((f'dropout{i+1}', nn.Dropout(p=drop_rate)))
        self.hidden_layers.append((f'linear{len(self.hidden_size)}', nn.Linear(
                            in_features = self.hidden_size[-1],
                            out_features = output_features,
                            bias=bias
                        )))
        # output layer
        self.output_layer = Output(output_features, output_features, init=1)
        print (self.hidden_layers)
        self.fc = nn.Sequential(OrderedDict(self.hidden_layers))


    def forward(self, x):
        phi = self.fc(x)
        y = self.output_layer(phi)
        return y
    
    def model(self):
        return self.fc

    def head(self):
        return self.output_layer
     
    
def reset_parameters(module:nn.Module, method='default'):
    if method=='default':
        for layer in module.children():
            if hasattr(layer, 'reset_parameters'):
                layer.reset_parameters()
            else:
                reset_parameters(layer, method)
    elif method=='normal':
        for p in module.parameters():
            nn.init.normal_(p)
    elif method=='constant':
        for p in module.parameters():
            nn.init.constant_(p, 1)
        
    else:
        raise NotImplementedError


global loss_register
loss_register = Register('loss_register')


class Loss:
    def __init__(self, weight=None):
        self.weight = weight
    
    def update_weight(self, weight):
        '''
        Args:
            weight: tensor or None
        '''
        self.weight = weight

    def __call__(self, predict, target, env, reduction='mean'):
        raise NotImplementedError

@loss_register.register
class bce_loss(Loss):
    def __call__(self, predict, target, env, reduction='mean'):
        loss = nn.BCEWithLogitsLoss(reduction='none')(predict, target.float())
        if reduction == 'none':
            return loss
        elif reduction == 'mean':
            total_loss = 0
            env_list = env.unique()
            for env_id in env_list:
                total_loss += loss[env==env_id].mean()
            total_loss /= len(env_list)
            return total_loss
        else:
            raise NotImplementedError
      
@loss_register.register
class groupDRO(Loss):
    def __init__(self, risk:Loss, device, n_env=2, eta=0.05):
        super(groupDRO, self).__init__()
        self.risk = risk                    # bce_loss: Loss. Call self.risk(predict, target, env, reduction='mean' or 'none') to calculate loss
        self.device = device
        self.n_env = n_env                  # two environments
        self.eta = eta                      # hyperparameter of groupDRO
        self.prob = np.ones(n_env) / n_env  # weight of each environment, initialized as uniform
    def __call__(self, predict, target, env, reduction='mean'):
        loss = self.risk(predict, target, env, reduction='none')
        
        if reduction == 'none':
            return loss
        elif reduction == 'mean':
            env_losses = []
            for i in range(self.n_env):
                env_mask = (env == i)
                if env_mask.sum() > 0:
                    env_loss = loss[env_mask].mean()
                else:
                    env_loss = torch.tensor(0.0, device=self.device)
                env_losses.append(env_loss)

            with torch.no_grad():
                for i in range(self.n_env):
                    # q = q * exp(eta * loss)
                    self.prob[i] = self.prob[i] * np.exp(self.eta * env_losses[i].item())
                self.prob = self.prob / self.prob.sum()

            group_dro_loss = 0
            for i in range(self.n_env):
                group_dro_loss += self.prob[i] * env_losses[i]
                
            return group_dro_loss
        else:
            raise NotImplementedError
        

def flatten_and_concat_variables(vs):
    """Flatten and concat variables to make a single flat vector variable."""
    flatten_vs = [torch.flatten(v) for v in vs]
    return torch.cat(flatten_vs, axis=0)

@loss_register.register
class IRM(Loss):
    def __call__(self, predict, target, env, network:nn.Module, risk:Loss):
        """
        Calculate IRM loss penalty
        """
        env_list = env.unique()
        penalty = 0.0

        for env_id in env_list:
            env_mask = (env == env_id)
            env_predict = predict[env_mask]
            env_target = target[env_mask]
            env_labels = env[env_mask]

            env_loss = risk(env_predict, env_target, env_labels, reduction='mean')
            grads = torch.autograd.grad(
                env_loss, 
                network.parameters(), 
                create_graph=True, 
                allow_unused=True
            )

            grads = [g for g in grads if g is not None]

            if len(grads) > 0:
                flat_grads = flatten_and_concat_variables(grads)
                env_penalty = torch.sum(flat_grads ** 2)
                penalty += env_penalty

        penalty = penalty / len(env_list)
        return penalty
